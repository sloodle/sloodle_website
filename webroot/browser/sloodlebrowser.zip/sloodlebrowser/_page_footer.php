		<div style="clear: both;">&nbsp;</div>
	</div>
</div>
<!-- end page -->
<hr />
<div id="footer">
	<p>
     Site developed by <a href="http://peter.avid-insight.co.uk" title="Click here to visit the web-developer's site">Peter R. Bloomfield</a>.
    </p>
    <p> 
     Original design by
      <a href="http://www.nodethirtythree.com/" title="Visit the designer's website">NodeThirtyThree</a>
      and
      <a href="http://www.freecsstemplates.org/" title="Visit the designer's website">Free CSS Templates</a>.
    </p>
    <p>
     <a href="http://www.secondlife.com" title="Official Second Life website">Second Life</a>
     is a registered trademark of Linden Lab. All rights reserved.<br/>
     Neither the Sloodle Browser nor the Sloodle project is affiliated with or endorsed by Linden Lab.
    </p>
</div>
</body>
</html>
