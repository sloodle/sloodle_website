<div><table cellpadding=0 cellspacing=0 style="width:100%;"><tr><td><div style="font-size:1px;width:6px;height:20px;"></div></td><td style="width:100%;">
<ul id="qm0" class="qmmc">

<?php
// Automatic menu building -- added by PRB.
// Each entry is an array containing the link URL, caption, and name.


$siteroot = 'http://www.sloodle.org';
$moodleroot = 'http://www.sloodle.org/moodle';

$navMenuEntries = array();
$navMenuEntries[] = array($moodleroot.'/',                                          'Return to the SLOODLE homepage', 'Home');
$navMenuEntries[] = array($moodleroot.'/mod/forum/view.php?f=14',                   'Read the latest SLOODLE news', 'News');
$navMenuEntries[] = array($siteroot.'/blog/?page_id=33',                               'Browse our tutorials', 'Tutorials');
$navMenuEntries[] = array($moodleroot.'/mod/forum/index.php?id=3',                  'Read or post on our forums (requires login)', 'Forums');
$navMenuEntries[] = array('http://slisweb.sjsu.edu/sl/index.php/Download_Sloodle',  'Download SLOODLE', 'Downloads');
$navMenuEntries[] = array($siteroot.'/blog/?page_id=30',                                'Read about SLOODLE-related research', 'Research');
$navMenuEntries[] = array($siteroot.'/blog/?page_id=2',                                   'Learn what SLOODLE is all about', 'About');
$navMenuEntries[] = array('http://www.sloodle.org/blog',                            'Read our official SLOODLE blog', 'Blog');
$navMenuEntries[] = array('http://slisweb.sjsu.edu/sl/index.php/Sloodle',           'Visit our wiki for documentation and other information', 'Wiki');

// Output each menu entry
$isfirst = true;
foreach ($navMenuEntries as $entry) {
    // Output separators
    if ($isfirst) $isfirst = false;
    else echo '<li><span class="qmdivider qmdividery" ></span></li>';
    // Output the menu item
    echo "<li><a class=\"\" href=\"{$entry[0]}\" title=\"{$entry[1]}\">{$entry[2]}</a></li>";
}

?>
		
<li class="qmclear">&nbsp;</li></ul></td></tr></table>


</div>
<!-- Create Menu Settings: (Menu ID, Is Vertical, Show Timer, Hide Timer, On Click ('all', 'main' or 'lev2'), Right to Left, Horizontal Subs, Flush Left, Flush Top) -->
<script type="text/javascript">qm_create(0,false,0,500,false,false,false,false,false);</script>
